module.exports = {
  mongoURI: 'mongodb+srv://f21ao-g0:W9hTPR6MAs3nXgu4@hwud-cluster.kn0tw1v.mongodb.net/?retryWrites=true&w=majority',
  jwtSecret: '86090ef8f8816c120dbbacf801fbeded6da15c2848d505c9796c79db575ddc10',
  jwtExpiry: "6h",
  AWS_ACCESS_KEY_ID : 'AKIA2QYMOOCWBTTYCA6C',
  AWS_SECRET_ACCESS_KEY : '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',
  AWS_BUCKET : 'f21devops',
  AWS_REGION : 'ap-south-1',
  AWS_SIGNATURE : 'v4',
};