module.exports = {
  port: 3000,
  mongoURI: 'mongodb+srv://f21ao-g0:W9hTPR6MAs3nXgu4@hwud-cluster.kn0tw1v.mongodb.net/?retryWrites=true&w=majority',
  jwtSecret: '86090ef8f8816c120dbbacf801fbeded6da15c2848d505c9796c79db575ddc10',
  jwtExpiry: "6h"
};