# To run server
Navigate to the F21AO-CW directory and run `node src/server.js`