module.exports = {
  jwtSecret: '86090ef8f8816c120dbbacf801fbeded6da15c2848d505c9796c79db575ddc10',
  jwtExpiry: "6h",
};